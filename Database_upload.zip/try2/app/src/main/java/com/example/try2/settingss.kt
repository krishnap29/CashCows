package com.example.try2
import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity

class settingss :AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.action_settings_button)

    }

}