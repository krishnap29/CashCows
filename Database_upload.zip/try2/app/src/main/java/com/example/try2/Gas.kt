package com.example.try2

class Gas(val idgas: String, val gasValue: Int)