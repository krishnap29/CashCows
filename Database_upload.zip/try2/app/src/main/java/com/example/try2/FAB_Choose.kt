package com.example.try2
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase

class FAB_Choose :AppCompatActivity(){
    lateinit var gasText: EditText
    lateinit var gasbuttonsave: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fab_choose_buttons)

        gasText = findViewById(R.id.gasText)
        gasbuttonsave = findViewById(R.id.gasButton)




        gasbuttonsave.setOnClickListener{
            val text = "button pressed!"
            val duration = Toast.LENGTH_SHORT

            val toast = Toast.makeText(applicationContext, text, duration)
            toast.show()
            saveValueGas()
        }

    }

    private fun saveValueGas(){
        val gasValue = gasText.text.toString().toInt()
        val ref = FirebaseDatabase.getInstance().getReference("Gas")
        val gasID = ref.push().key

        val gas = gasID?.let { Gas(it, gasValue) }

        if (gasID != null) {
            ref.child(gasID).setValue(gas)
        }

    }


}